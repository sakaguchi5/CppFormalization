import CppFormalization.Cpp2.Closure.External.ReadyFromGlueV3
import CppFormalization.Cpp2.Closure.External.CanonicityV3
import CppFormalization.Cpp2.Closure.External.AssembleLemmasV3
import CppFormalization.Cpp2.Closure.External.TransportV3
import CppFormalization.Cpp2.Closure.External.ToyReadyInstanceV3

namespace Cpp

/-!
# Closure.External.ToyGlueInstanceV3

First concrete inhabited low-level glue instance for the redesigned V3.

Role in the roadmap:
- show that the low-level glue route is inhabited on the same toy family,
- show that the direct ready route and the direct glue route agree at the
  visible-package level and at the official boundary quotient,
- show that the toy family also satisfies the Stage 2C canonicity vocabulary.

After the Stage 2A/2B/2C refactor, this file is intentionally kept concrete:
generic projection, transport, and canonicity lemmas live in dedicated
infrastructure files.
-/

/-- Toy low-level glue: compatibility is the same canonical certificate identity. -/
def toyGlueV3 :
    VerifiedExternalGlueV3 toyStdFragmentV3 toyReflectionFragmentV3 where
  compatible := toyReadyAssemblyV3.compatible
  mkAdequacy := by
    intro n m Γ σ st _ _ hgen hsuppRefl hcompat
    rcases hcompat with ⟨rfl, rfl, rfl, rfl⟩
    rcases hsuppRefl with ⟨_, _⟩
    simpa [toyReflectionFragmentV3] using n.ready.toAdequacy


theorem toyGlue_compatible (c : ToyReadyCertificate) :
    toyGlueV3.compatible c c c.Γ c.σ c.st := by
  exact toy_compatible c

/-- Canonical explicit V3 pieces assembled from the toy low-level glue route. -/
def toyGlueExternalPiecesV3
    (c : ToyReadyCertificate) :
    ExternalPiecesV3 c.Γ c.σ c.st :=
  assembleExternalPiecesV3 toyGlueV3
    (toy_uses c)
    (toy_supportsRuntime c)
    (toy_generates c)
    (toy_supportsReflection c)
    (toyGlue_compatible c)


theorem toyGlueExternalPiecesV3_profile
    (c : ToyReadyCertificate) :
    (toyGlueExternalPiecesV3 c).profile = c.ready.toProfile := by
  have h :=
    assembleExternalPiecesV3_profile
      (G := toyGlueV3)
      (huse := toy_uses c)
      (hsuppRun := toy_supportsRuntime c)
      (hgen := toy_generates c)
      (hsuppRefl := toy_supportsReflection c)
      (hcompat := toyGlue_compatible c)
  simpa [toyGlueExternalPiecesV3, toyReflectionFragmentV3_profile c] using h


theorem toyGlueExternalPiecesV3_structural
    (c : ToyReadyCertificate) :
    (toyGlueExternalPiecesV3 c).structural = c.ready.toStructural := by
  have h :=
    assembleExternalPiecesV3_structural
      (G := toyGlueV3)
      (huse := toy_uses c)
      (hsuppRun := toy_supportsRuntime c)
      (hgen := toy_generates c)
      (hsuppRefl := toy_supportsReflection c)
      (hcompat := toyGlue_compatible c)
  simpa [toyGlueExternalPiecesV3, toyReflectionFragmentV3_structural c] using h


theorem toyGlueExternalPiecesV3_dynamic
    (c : ToyReadyCertificate) :
    (toyGlueExternalPiecesV3 c).dynamic = c.ready.toDynamic := by
  have h :=
    assembleExternalPiecesV3_dynamic
      (G := toyGlueV3)
      (huse := toy_uses c)
      (hsuppRun := toy_supportsRuntime c)
      (hgen := toy_generates c)
      (hsuppRefl := toy_supportsReflection c)
      (hcompat := toyGlue_compatible c)
  cases c
  simpa [toyGlueExternalPiecesV3, toyStdFragmentV3]
    using h


theorem toyGlueExternalPiecesV3_core
    (c : ToyReadyCertificate) :
    (toyGlueExternalPiecesV3 c).core = c.core := by
  have h :=
    assembleExternalPiecesV3_core
      (G := toyGlueV3)
      (huse := toy_uses c)
      (hsuppRun := toy_supportsRuntime c)
      (hgen := toy_generates c)
      (hsuppRefl := toy_supportsReflection c)
      (hcompat := toyGlue_compatible c)
  simpa [toyGlueExternalPiecesV3, toyReflectionFragmentV3_core c] using h


theorem toyGlueExternalPiecesV3_adequacy
    (c : ToyReadyCertificate) :
    (toyGlueExternalPiecesV3 c).adequacy = c.ready.toAdequacy := by
  have h :=
    assembleExternalPiecesV3_adequacy
      (G := toyGlueV3)
      (huse := toy_uses c)
      (hsuppRun := toy_supportsRuntime c)
      (hgen := toy_generates c)
      (hsuppRefl := toy_supportsReflection c)
      (hcompat := toyGlue_compatible c)
  cases c
  simpa [toyGlueExternalPiecesV3, toyGlueV3, toyReadyAssemblyV3]
    using h


theorem toyGlueExternalPiecesV3_boundary_adequacy
    (c : ToyReadyCertificate) :
    castBodyAdequacy (toyGlueExternalPiecesV3_profile c)
      ((toyGlueExternalPiecesV3 c).toBodyBoundary.adequacy) =
      (c.ready.toClosureBoundary).adequacy := by
  cases c
  rfl


theorem toyGlueExternalPiecesV3_boundary
    (c : ToyReadyCertificate) :
    (toyGlueExternalPiecesV3 c).toBodyBoundary = c.ready.toClosureBoundary := by
  ext
  · exact toyGlueExternalPiecesV3_structural c
  · exact toyGlueExternalPiecesV3_profile c
  · exact toyGlueExternalPiecesV3_dynamic c
  · exact toyGlueExternalPiecesV3_boundary_adequacy c

/-- The glue-side visible package is exactly the canonical package of the toy target. -/
theorem toyGlueExternalPiecesV3_packageCoherent
    (c : ToyReadyCertificate) :
    PackageCoherentV3
      (toyGlueExternalPiecesV3 c).toVisiblePieces
      (canonicalVisiblePiecesV3
        (toy_uses c)
        (toy_supportsRuntime c)
        (toy_generates c)
        (toy_supportsReflection c)) := by
  simpa [toyGlueExternalPiecesV3] using
    (assembleExternalPiecesV3_packageCoherent
      (G := toyGlueV3)
      (huse := toy_uses c)
      (hsuppRun := toy_supportsRuntime c)
      (hgen := toy_generates c)
      (hsuppRefl := toy_supportsReflection c)
      (hcompat := toyGlue_compatible c))


theorem toyReady_dynamic_unique
    {Γ : TypeEnv} {σ : State} {st : CppStmt}
    (r₁ r₂ : BodyReadyCI Γ σ st) :
    r₁.toDynamic = r₂.toDynamic := by
  exact Subsingleton.elim _ _


theorem toyReady_structural_unique
    {Γ : TypeEnv} {σ₁ σ₂ : State} {st : CppStmt}
    (r₁ : BodyReadyCI Γ σ₁ st) (r₂ : BodyReadyCI Γ σ₂ st) :
    r₁.toStructural = r₂.toStructural := by
  exact Subsingleton.elim _ _


theorem toyReady_profile_unique
    {Γ : TypeEnv} {σ₁ σ₂ : State} {st : CppStmt}
    (r₁ : BodyReadyCI Γ σ₁ st) (r₂ : BodyReadyCI Γ σ₂ st) :
    r₁.toProfile = r₂.toProfile := by
  exact Subsingleton.elim _ _


theorem toyCore_unique
    {st : CppStmt} (c₁ c₂ : CoreBigStepFragment st) :
    c₁ = c₂ := by
  exact Subsingleton.elim _ _

/-- The toy runtime family is target-canonical. -/
theorem toyRuntimePackageUniqueV3 :
    RuntimePackageUniqueV3 toyStdFragmentV3 := by
  intro n₁ n₂ Γ σ st huse₁ hsupp₁ huse₂ hsupp₂
  cases n₁ with
  | mk Γ₁ σ₁ st₁ ready₁ core₁ =>
    cases n₂ with
    | mk Γ₂ σ₂ st₂ ready₂ core₂ =>
      simp [toyStdFragmentV3] at hsupp₁ hsupp₂ ⊢
      rcases hsupp₁ with ⟨rfl, rfl, rfl⟩
      rcases hsupp₂ with ⟨rfl, rfl, rfl⟩
      ext
      exact toyReady_dynamic_unique ready₁ ready₂

/-- The toy reflection family is target-canonical. -/
theorem toyReflectionPackageUniqueV3 :
    ReflectionPackageUniqueV3 toyReflectionFragmentV3 := by
  intro m₁ m₂ Γ st hgen₁ hsupp₁ hgen₂ hsupp₂
  cases m₁ with
  | mk Γ₁ σ₁ st₁ ready₁ core₁ =>
    cases m₂ with
    | mk Γ₂ σ₂ st₂ ready₂ core₂ =>
      simp [toyReflectionFragmentV3] at hgen₁ hsupp₁ hgen₂ hsupp₂ ⊢
      rcases hgen₁ with rfl
      rcases hsupp₁ with ⟨rfl, rfl⟩
      rcases hgen₂ with rfl
      rcases hsupp₂ with ⟨rfl, rfl⟩
      ext
      · exact toyReady_structural_unique ready₁ ready₂
      · exact toyReady_profile_unique ready₁ ready₂
      · exact toyCore_unique core₁ core₂


theorem toyCanonicalVisiblePiecesV3_wellDefined
    {n₁ n₂ : toyStdFragmentV3.Name} {m₁ m₂ : toyReflectionFragmentV3.Meta}
    {Γ : TypeEnv} {σ : State} {st : CppStmt}
    (huse₁ : toyStdFragmentV3.uses n₁)
    (hsuppRun₁ : toyStdFragmentV3.supportsRuntime n₁ Γ σ st)
    (hgen₁ : toyReflectionFragmentV3.generates m₁ st)
    (hsuppRefl₁ : toyReflectionFragmentV3.supportsReflection m₁ Γ st)
    (huse₂ : toyStdFragmentV3.uses n₂)
    (hsuppRun₂ : toyStdFragmentV3.supportsRuntime n₂ Γ σ st)
    (hgen₂ : toyReflectionFragmentV3.generates m₂ st)
    (hsuppRefl₂ : toyReflectionFragmentV3.supportsReflection m₂ Γ st) :
    canonicalVisiblePiecesV3 huse₁ hsuppRun₁ hgen₁ hsuppRefl₁ =
      canonicalVisiblePiecesV3 huse₂ hsuppRun₂ hgen₂ hsuppRefl₂ := by
  exact canonicalVisiblePiecesV3_wellDefined
    toyRuntimePackageUniqueV3
    toyReflectionPackageUniqueV3
    huse₁ hsuppRun₁ hgen₁ hsuppRefl₁
    huse₂ hsuppRun₂ hgen₂ hsuppRefl₂


theorem toyCanonicalVisiblePiecesV3_packageCoherent
    {n₁ n₂ : toyStdFragmentV3.Name} {m₁ m₂ : toyReflectionFragmentV3.Meta}
    {Γ : TypeEnv} {σ : State} {st : CppStmt}
    (huse₁ : toyStdFragmentV3.uses n₁)
    (hsuppRun₁ : toyStdFragmentV3.supportsRuntime n₁ Γ σ st)
    (hgen₁ : toyReflectionFragmentV3.generates m₁ st)
    (hsuppRefl₁ : toyReflectionFragmentV3.supportsReflection m₁ Γ st)
    (huse₂ : toyStdFragmentV3.uses n₂)
    (hsuppRun₂ : toyStdFragmentV3.supportsRuntime n₂ Γ σ st)
    (hgen₂ : toyReflectionFragmentV3.generates m₂ st)
    (hsuppRefl₂ : toyReflectionFragmentV3.supportsReflection m₂ Γ st) :
    PackageCoherentV3
      (canonicalVisiblePiecesV3 huse₁ hsuppRun₁ hgen₁ hsuppRefl₁)
      (canonicalVisiblePiecesV3 huse₂ hsuppRun₂ hgen₂ hsuppRefl₂) := by
  exact canonicalVisiblePiecesV3_packageCoherent
    toyRuntimePackageUniqueV3
    toyReflectionPackageUniqueV3
    huse₁ hsuppRun₁ hgen₁ hsuppRefl₁
    huse₂ hsuppRun₂ hgen₂ hsuppRefl₂

/-- Concrete package-level route coherence on the first inhabited family. -/
theorem toy_ready_vs_glue_packageCoherent
    (c : ToyReadyCertificate) :
    PackageCoherentV3
      (toyExternalPiecesV3 c).toVisiblePieces
      (toyGlueExternalPiecesV3 c).toVisiblePieces := by
  calc
    (toyExternalPiecesV3 c).toVisiblePieces =
        canonicalVisiblePiecesV3
          (toy_uses c) (toy_supportsRuntime c)
          (toy_generates c) (toy_supportsReflection c) := by
            exact externalPieces_of_ready_v3_packageCoherent
              (A := toyReadyAssemblyV3)
              (huse := toy_uses c)
              (hsuppRun := toy_supportsRuntime c)
              (hgen := toy_generates c)
              (hsuppRefl := toy_supportsReflection c)
              (hcompat := toy_compatible c)
    _ = (toyGlueExternalPiecesV3 c).toVisiblePieces := by
          symm
          exact toyGlueExternalPiecesV3_packageCoherent c

/-- Concrete boundary-level route coherence on the first inhabited family. -/
theorem toy_ready_vs_glue_boundaryCoherent
    (c : ToyReadyCertificate) :
    BoundaryCoherentV3 (toyExternalPiecesV3 c) (toyGlueExternalPiecesV3 c) := by
  change (toyExternalPiecesV3 c).toBodyBoundary = (toyGlueExternalPiecesV3 c).toBodyBoundary
  calc
    (toyExternalPiecesV3 c).toBodyBoundary = c.ready.toClosureBoundary := by
      exact toyExternalPiecesV3_boundary c
    _ = (toyGlueExternalPiecesV3 c).toBodyBoundary := by
      symm
      exact toyGlueExternalPiecesV3_boundary c

/-- The induced ready route from the toy glue is package-coherent with the direct glue route. -/
theorem toy_glue_readyInduced_packageCoherent
    (c : ToyReadyCertificate) :
    PackageCoherentV3
      (externalPieces_of_ready_v3
        (readyAssembly_of_glue_v3 toyGlueV3)
        (toy_uses c) (toy_supportsRuntime c)
        (toy_generates c) (toy_supportsReflection c) (toyGlue_compatible c)).toVisiblePieces
      (toyGlueExternalPiecesV3 c).toVisiblePieces := by
  exact externalPieces_of_ready_from_glue_v3_packageCoherent
    toyGlueV3 (toy_uses c) (toy_supportsRuntime c)
    (toy_generates c) (toy_supportsReflection c) (toyGlue_compatible c)

/-- The induced ready route from the toy glue is boundary-coherent with the direct glue route. -/
theorem toy_glue_readyInduced_boundaryCoherent
    (c : ToyReadyCertificate) :
    BoundaryCoherentV3
      (externalPieces_of_ready_v3
        (readyAssembly_of_glue_v3 toyGlueV3)
        (toy_uses c) (toy_supportsRuntime c)
        (toy_generates c) (toy_supportsReflection c) (toyGlue_compatible c))
      (toyGlueExternalPiecesV3 c) := by
  exact externalPieces_of_ready_from_glue_v3_boundaryCoherent
    toyGlueV3 (toy_uses c) (toy_supportsRuntime c)
    (toy_generates c) (toy_supportsReflection c) (toyGlue_compatible c)

/-- First concrete inhabited statement-level closure instance for the low-level V3 route. -/
theorem toy_glue_certificate_closure
    (c : ToyReadyCertificate) :
    BigStepStmtTerminates c.σ c.st ∨ BigStepStmtDiv c.σ c.st := by
  exact
    reflective_std_closure_theorem_v3_via_ready
      toyGlueV3
      (toy_uses c)
      (toy_supportsRuntime c)
      (toy_generates c)
      (toy_supportsReflection c)
      (toyGlue_compatible c)

/-- Function-body variant of the first concrete inhabited low-level V3 instance. -/
theorem toy_glue_certificate_function_body_closure
    (c : ToyReadyCertificate) :
    (∃ ex σ', BigStepFunctionBody c.σ c.st ex σ') ∨ BigStepStmtDiv c.σ c.st := by
  exact
    reflective_std_function_body_closure_v3_via_ready
      toyGlueV3
      (toy_uses c)
      (toy_supportsRuntime c)
      (toy_generates c)
      (toy_supportsReflection c)
      (toyGlue_compatible c)

end Cpp
